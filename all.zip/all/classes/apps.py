from django.apps import AppConfig


class ClassesConfig(AppConfig):
    name = 'classes'
